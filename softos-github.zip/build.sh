#!/usr/bin/env bash
set -euo pipefail

OS_NAME="Soft OS"
ISO_NAME="softos"
DIST="bookworm"
ARCH="amd64"

sudo lb clean || true

sudo lb config \  --mode debian \  --distribution "$DIST" \  --architecture "$ARCH" \  --debian-installer live \  --binary-images iso-hybrid \  --bootloader syslinux \  --archive-areas "main contrib non-free non-free-firmware" \  --apt-indices true \  --updates true \  --security true \  --mirror-bootstrap http://deb.debian.org/debian \  --mirror-binary http://deb.debian.org/debian \  --mirror-binary-security http://security.debian.org/debian-security

export LB_LINUX_FLAVOURS="amd64"
export LB_ISO_APPLICATION="$OS_NAME"
export LB_ISO_PREPARER="Softman"
export LB_ISO_VOLUME="${ISO_NAME^^}-LIVE"

rsync -a ./config . 2>/dev/null || true

sudo lb build

OUT=$(ls -1t *.hybrid.iso *.iso 2>/dev/null | head -n1 || true)
if [[ -n "$OUT" ]]; then
  mv -f "$OUT" "${ISO_NAME}-${DIST}-${ARCH}.iso"
  echo "ISO gerado: ${ISO_NAME}-${DIST}-${ARCH}.iso"
else
  echo "Falha: ISO não encontrado. Verifique os logs." >&2
  exit 1
fi
