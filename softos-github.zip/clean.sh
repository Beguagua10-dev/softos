#!/usr/bin/env bash
set -euo pipefail
sudo lb clean --purge || true
sudo rm -rf cache chroot binary local || true
sudo rm -f *.iso *.hybrid.iso || true
